exports.mysql = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'NMHBSource'
}

exports.mongo = 'mongodb://localhost:27017/pub2'

exports.cache = {
    make: false,
    url: 'http://localhost:4000'
}